package VultBurglary;

public interface VultBurglarySystem {

    public void addPassage(int firstNode, int secondNode);

    public int getMaxFlux(int flux, int dreno);

/*     public void addBefore(int flux); */
}
